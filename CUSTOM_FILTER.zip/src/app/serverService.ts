import {Injectable} from "@angular/core";
import {Http,Headers,Response} from "@angular/http";
import "rxjs/Rx";
import {Observable} from "rxjs/Observable";
@Injectable()
export class ServerService{
    constructor(private http:Http){}

    saveData(countries:any){
        const headers=new Headers({
            'Content-Type':'application/json'
        }) 
        return  this.http.put("https://rahul-http.firebaseio.com/data.json",countries);
    }

    getCountry(){
        return this.http.get('https://rahul-http.firebaseio.com/data'+".json").map(
            (response:Response)=>{
                return response;
            },
            (error:Response)=>{
                return Observable.throw(error);
            }
        ).catch(
            (error:Response)=>{
                return Observable.throw(error);
            }
        )
    }

}