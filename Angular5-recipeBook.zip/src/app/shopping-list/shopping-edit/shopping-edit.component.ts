import { Component, OnInit,OnDestroy,ViewChild} from '@angular/core';
import { Ingredient } from "../../shared/ingredient.model";
import { ShoppingListService } from "../shopping-list.service";
import {NgForm} from "@angular/forms";
import {Subscription} from "rxjs/Subscription";

@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.css']
})
export class ShoppingEditComponent implements OnInit,OnDestroy {
  subscription:Subscription;
  editMode=false;
  editedItemIndex:number;
  editedIngredient:Ingredient;
  @ViewChild('f') shopingListForm:NgForm;
  
  constructor(private shoppingList:ShoppingListService) { }

  ngOnInit() {
    this.subscription=this.shoppingList.startedEditing.subscribe(
      (index:number)=>{
          this.editMode=true;
          this.editedItemIndex=index;
          this.editedIngredient=this.shoppingList.getIngredient(index);
          this.shopingListForm.setValue({
            name:this.editedIngredient.name,
            amount:this.editedIngredient.amount
          })
      }
    )
  }

  onSubmitItem(form:NgForm){
    const value=form.value;
    const newIngredient=new Ingredient(value.name,value.amount);
    if(this.editMode){
        this.shoppingList.updateIngredient(this.editedItemIndex,newIngredient);
    }else{
        this.shoppingList.addIngredient(newIngredient);
    } 
    form.reset();
    this.editMode=false;
    
  }

  onClear(){
    this.shopingListForm.reset();
    this.editMode=false;
  }

  ngOnDestroy(){
    this.subscription.unsubscribe();
  }

  onDelete(){
    this.shoppingList.deleteIngredient(this.editedItemIndex);
    this.onClear();
  }
  

}
