import { Ingredient } from "../shared/ingredient.model";
import {Subject} from "rxjs/Subject"

export class ShoppingListService{
    integredientChanged=new Subject<Ingredient[]>();
    startedEditing=new Subject<number>();

    private ingredients:Ingredient[]=[
     new Ingredient("apple",5),
     new Ingredient("tomato",10),
  ];

    getIngredients(){
      return this.ingredients.slice();
    }

    getIngredient(index:number){
      return this.ingredients.slice()[index];
    }

    addIngredient(ingredient:Ingredient){
        this.ingredients.push(ingredient);
        this.integredientChanged.next(this.getIngredients())
    }

     addIngredients(ingredient:Ingredient[]){
        this.ingredients.push(...ingredient);
        this.integredientChanged.next(this.getIngredients())
    }

    updateIngredient(index:number,newIngredient:Ingredient){
      this.ingredients[index]=newIngredient;
       this.integredientChanged.next(this.getIngredients())
    }

    deleteIngredient(index:number){
      this.ingredients.splice(index,1)
      this.integredientChanged.next(this.getIngredients())
    }

}