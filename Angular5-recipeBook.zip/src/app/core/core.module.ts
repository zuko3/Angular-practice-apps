import {NgModule} from "@angular/core";
import {SharedModule} from "../shared/shared.module";
import {HeaderComponent} from './header/header.component';
import { HomeComponent } from './home/home.component';
import { ShoppingListService } from "../shopping-list/shopping-list.service";
import { RecipesService } from "../recipes/recipes.service";
import { DataStorageService } from "../shared/data.storage.service";
import { AuthService } from '../auth/auth.service';
import {CommonModule} from "@angular/common";
import { RouterModule } from '@angular/router';

@NgModule({
     declarations: [
         HeaderComponent,
         HomeComponent
     ],
     imports:[
         SharedModule,
         RouterModule
     ],
     providers: [
        ShoppingListService,
        RecipesService,
        DataStorageService,
        AuthService    
  ],
  exports:[
    HeaderComponent  
  ]
})
export class CoreModule{}