import { Component ,OnInit} from '@angular/core';
import * as firebase from "firebase";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';
  loadedFeature='recipe';

  ngOnInit(){
          var config = {
          apiKey: "AIzaSyC8qvTTOHu1growPx4_oWz7eht4bI1u4us",
          authDomain: "recipe-book-3def3.firebaseapp.com"
        };
        firebase.initializeApp(config);
  }
  
  onNavigate(feature:string){
    this.loadedFeature=feature;
  }
}
