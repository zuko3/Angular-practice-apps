import * as firebase from "firebase";
import {Router} from "@angular/router";
import {Injectable} from "@angular/core";

@Injectable()
export class AuthService{
    token:string;
    constructor(private router:Router){}
    signupUser(email:string,password:string){
        return firebase.auth().createUserWithEmailAndPassword(email,password).
        then(
            response =>{
                    this.router.navigate(["/"]);
                    firebase.auth().currentUser.getToken()
                    .then(
                        (token:string)=>this.token=token
                    );
                    return {status:"sucess",errorm:""};
            } 
        ).
        catch(
            error => {
                console.log(error);
                 return {status:"error",errorm:error.message};
            }
        );
    }

    signInUser(email:string,password:string){
         return firebase.auth().signInWithEmailAndPassword(email,password).
        then(
            response =>{
                    this.router.navigate(["/"]);
                    firebase.auth().currentUser.getToken()
                    .then(
                        (token:string)=>this.token=token
                    );
                   return {status:"sucess",errorm:""};
            } 
        ).
        catch(
            error => {
                console.log(error)
                  return {status:"error",errorm:error.message};
            }
        );
    }

    getToken(){
         firebase.auth().currentUser.getToken()
        .then(
                (token:string)=>this.token=token
            )
        return this.token;
    }

    isAuthenticated(){
        if(this.token){
            return true;
        }else{
            return false;
        }
    }

    logout(){
        firebase.auth().signOut();
        this.token=null;
        this.router.navigate(["/"]);
    }
}