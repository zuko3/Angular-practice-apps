import { Recipe } from './recipe.model';
import {Injectable} from "@angular/core";
import { Ingredient } from "../shared/ingredient.model";
import { ShoppingListService } from "../shopping-list/shopping-list.service";
import {Subject} from "rxjs/Subject"

@Injectable()
export class RecipesService{   

    recipeChanged = new Subject<Recipe[]>();
    private recipes:Recipe[] = [
    new Recipe(
            "chicken",
            "This chicken recipe",
            "http://www.seriouseats.com/recipes/assets_c/2015/01/20150119-pressure-cooker-chicken-stew-food-lab-11-thumb-1500xauto-418088.jpg",
            [new Ingredient("chicken",1),new Ingredient("tomato",10)]
        ),
    new Recipe(
            "Slamon",
            "This is the Slamon recipe",
            "https://static01.nyt.com/images/2016/02/16/dining/16COOKING-SALMONWITHLEEKS2/16COOKING-SALMONWITHLEEKS2-articleLarge.jpg",
            [new Ingredient("salamon",1),new Ingredient("tomato",10)]
        )
  ];

  constructor(private shopingListService:ShoppingListService){}

  getRecipes(){
      return this.recipes.slice()
  }

  setRecipe(recipes:Recipe[]){
      this.recipes=recipes;
      this.recipeChanged.next(this.getRecipes())

  }

  

  addIngredientToShopingList(ingredient:Ingredient[]){
      this.shopingListService.addIngredients(ingredient);
  }

  getRecipe(index:number){
     return  this.recipes[index];
  }

  addRecipe(recipe:Recipe){
      this.recipes.push(recipe);
      this.recipeChanged.next(this.getRecipes())
  }

  updateRecipe(index:number,newRecipe:Recipe){
      this.recipes[index]=newRecipe;
      this.recipeChanged.next(this.getRecipes())
  }

  deleteRecipe(index:number){
     this.recipes.splice(index,1);
      this.recipeChanged.next(this.getRecipes())
  }
}