import {Ingredient} from "../shared/ingredient.model"

export class Recipe {
    public name:string;
    public descrition:string;
    public imagepath:string;
    public ingredient:Ingredient[];

    constructor(name:string, description:string, imagepath:string,ingredient:Ingredient[]){
        this.name=name;
        this.descrition=description;
        this.imagepath=imagepath;
        this.ingredient=ingredient;
    }
}