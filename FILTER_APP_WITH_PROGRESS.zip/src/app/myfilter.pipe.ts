import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myfilter'
})
export class MyfilterPipe implements PipeTransform {

  transform(value: any, name?:any): any {
    if(!name){return value;}
    else{
      let countries=[];
      for(let con of value){
          if(con.toLowerCase().startsWith(name.toLowerCase())){countries.push(con);}
      }
      return countries;
    }
  }

}
