import { Component,
  ViewChild,
  state,
  trigger,
  style,
  transition,
  animate,
  keyframes,
  ElementRef
 } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  animations:[
    trigger('divState',[
      state('normal',style({
        'background-color':'red',
        transform:'translateX(0)'
      })),
      state('highlighted',style({
        'background-color':'blue',
        transform:'translateX(200px)'
      })),
      transition("* => *",animate(300))
    ]),


    trigger('list1',[
          state('in',style({
            opacity:1,
            transform:'translateX(0)'
          })),
         transition("void => *",[
              animate(1000,keyframes([
              style({
                            opacity:0,
                            transform:'translateX(-100px)',
                    offset:0
                      }),
              style({
                  opacity:0.3,
                  transform:'translateX(-50px)',
                  offset:0.3
                }),
              style({
                  opacity:0.8,
                  transform:'translateX(-20px)',
                  offset:0.8
                }),
              style({
                opacity:1,
                transform:'translateX(0px)',
                offset:1
              }),
            ]))
          ]),
            transition("* => void",[
                animate(300,style({
                    transform:'translateX(100px)',
                    opacity:0,
                  }))
            ])
      ]),

      ]
})
export class AppComponent {
  state="normal";
  @ViewChild('input') iteminput:ElementRef;
  list=[];
  
  onAdd(item){
    this.list.push(item);
  }

   onDelete(item){
    this.list.splice(this.list.indexOf(item),1);
  }
  onAnimate(){
    this.state=="highlighted"? this.state="normal":this.state="highlighted";
  }

  animationItemEnd(){
     this.iteminput.nativeElement.value="";
  }

  animationStarted(event){
    console.log(event);
  }

  animationEnd(event){
    console.log(event);
  }

 
}
